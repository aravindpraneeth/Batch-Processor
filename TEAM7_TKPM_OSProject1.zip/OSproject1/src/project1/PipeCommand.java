/* Operating systems CS5348
 * Project 1: Batch Processor project  
 * Team: 7   
 */
package project1;

import org.w3c.dom.Element;

public class PipeCommand extends Command{

	@Override
	public String describe() {
		// TODO Auto-generated method stub
		return null;
	}



	@Override
	public void parse(Element element) {
		// TODO Auto-generated method stub
		
	}
	}
