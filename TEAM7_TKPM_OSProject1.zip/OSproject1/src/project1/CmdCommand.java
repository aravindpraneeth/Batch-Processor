/* Operating systems CS5348
 * Project 1: Batch Processor project  
 * Team: 7   
 */

package project1;

import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

import org.w3c.dom.Element;

public class CmdCommand extends Command {
	String path;
	List<String> cmdArgs;
	String inID;
	String outID;

	@Override
	public String describe() {
		return "A CMD command {" + path + "\t" + cmdArgs.toString() + "}is executed.";
	}

	@Override
	public void parse(Element element) throws ProcessException {
		id = element.getAttribute("id");
		if (id == null || id.isEmpty()) {
			throw new ProcessException("Missing ID in CMD Command");
		}
		

		path = element.getAttribute("path");
		if (path == null || path.isEmpty()) {
			throw new ProcessException("Missing PATH in CMD Command");
		}
		

		// Arguments must be passed to ProcessBuilder as a list of
		// individual strings.
		cmdArgs = new ArrayList<String>();
		String arg = element.getAttribute("args");
		if (!(arg == null || arg.isEmpty())) {
			StringTokenizer st = new StringTokenizer(arg);
			while (st.hasMoreTokens()) {
				String tok = st.nextToken();
				cmdArgs.add(tok);
			}
		}
		

		inID = element.getAttribute("in");
		outID = element.getAttribute("out");
		
	}

}
