/* Operating systems CS5348
 * Project 1: Batch Processor project  
 * Team: 7   
 */
package project1;

import org.w3c.dom.Element;

//this class implements command class and implements its methods
public class FileCommand extends Command {
	String path;
	
	@Override
	public String describe() {		
		return "A File command with path"+path+"is executed.";
	}

	
	@Override
	public void parse(Element element) throws ProcessException {
		id = element.getAttribute("id");
		if (id == null || id.isEmpty()) {
			throw new ProcessException("Missing ID in CMD Command");
		}
		

		path = element.getAttribute("path");
		if (path == null || path.isEmpty()) {
			throw new ProcessException("Missing PATH in CMD Command");
		}
		
	}

	

}
